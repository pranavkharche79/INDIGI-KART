import React from 'react'
import './HomeCategories.css'
import img1 from '../../ASSETS/Images/1.png'
import img2 from '../../ASSETS/Images/2.png'
import img3 from '../../ASSETS/Images/3.png'
import img4 from '../../ASSETS/Images/4.png'

// const HomeCategories = () => {
//   return (
//     <div className='homecategories'>
//       <div className='container'>
//         <img src={img1} alt='img1' />
//         <div className='content'>
//           <h1>
//            Buy Grocery 
//           </h1>
//           <p> Shop Grains,Pulses and Many More...</p>
//         </div>
//       </div>
//       <div className='container'>
//         <img src={img2} alt='img2' />
//         <div className='content'>
//           <h1>
//            Buy Textiles & HandLooms 
//           </h1>
//           <p> Shop Kashmiri Shawls ,HandLooms and More...</p>
//         </div>
//       </div>
//       <div className='container'>
//         <img src={img3} alt='img3' />
//         <div className='content'>
//           <h1>
//             Buy Accessories
//           </h1>
//           <p> Shop Jewellery,Perfumes and Leather Accessories... </p>
//         </div>
//       </div>
//       <div className='container'>
//         <img src={img4} alt='img4' />
//          <div className='content'>
//           <h1>
//             Buy Art and HandiCrafts
//           </h1>
//           <p> Shop Paintings,Stone Crafts and Many More...</p>
//         </div>
//       </div>
//     </div>
//   )
// }

// export default HomeCategories

const HomeCategories = () => {
  const handleClick = (url) => {
    window.location.href = url;
  };

  return (
    <div className='homecategories'>
      <div className='container' onClick={() => handleClick('https://www.example.com/grocery')}>
        <img src={img1} alt='img1' />
        <div className='content'>
          <h1>
           Buy Grocery 
          </h1>
          <p> Shop Grains,Pulses and Many More...</p>
        </div>
      </div>
      <div className='container' onClick={() => handleClick('https://www.example.com/textiles')}>
        <img src={img2} alt='img2' />
        <div className='content'>
          <h1>
           Buy Textiles & HandLooms 
          </h1>
          <p> Shop Kashmiri Shawls ,HandLooms and More...</p>
        </div>
      </div>
      <div className='container' onClick={() => handleClick('https://www.example.com/accessories')}>
        <img src={img3} alt='img3' />
        <div className='content'>
          <h1>
            Buy Accessories
          </h1>
          <p> Shop Jewellery,Perfumes and Leather Accessories... </p>
        </div>
      </div>
      <div className='container' onClick={() => handleClick('https://www.example.com/art')}>
        <img src={img4} alt='img4' />
         <div className='content'>
          <h1>
            Buy Art and HandiCrafts
          </h1>
          <p> Shop Paintings,Stone Crafts and Many More...</p>
        </div>
      </div>
    </div>
  )
}

export default HomeCategories