import React from 'react'
import Slider from 'react-slick'
import './BannerSlider.css'

const BannerSlider = () => {
    const data = [
        {
            id: 1,
            image: 'https://img.freepik.com/premium-photo/dried-garlic-powder-bowl-top-view-isolated-white-background-organic-spice_84485-32.jpg?size=626&ext=jpg&ga=GA1.1.1951484713.1707916224&semt=ais',
            title: 'We Deliver Indigenous Product To Your Doorstep',
            description: 'From The Very Land To Your Hand',
            // button: 'htttps://www.google.com'
        },
        {
            id: 2,
            image: 'https://img.freepik.com/free-photo/multi-colored-spool-close-up-sewing-thread-background-generated-by-ai_188544-19540.jpg?size=626&ext=jpg&ga=GA1.1.1951484713.1707916224&semt=sph',
            title: 'Delivering A Wide Range Of Indigenous Products To Your DoorStep',
            description: '',
            // button: 'htttps://www.google.com'
        }
    ]


    var settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1
    };


    return (
        <div className='bannerslider'>
            <Slider className='bannerslider' {...settings}>
                {
                    data.map(item => {
                        return (
                            <div className='imagecont' key={item.id}>
                                <img src={item.image} alt='noimg' />
                                <div className='content'>
                                    <h1>{item.title}</h1>
                                    <span>{item.description}</span>
                                    {/* <button>Shop More</button> */}
                                </div>
                            </div>
                        )
                    })
                }
            </Slider>
        </div>
    )
}

export default BannerSlider